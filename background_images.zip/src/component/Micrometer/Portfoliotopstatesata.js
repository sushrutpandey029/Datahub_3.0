export default [
    {
      id: 1,
      states: "BH",
      PAR_30: "4.5%",
      PAR_90: "2.5%",
      PAR_180: "1.7%"
    },
    {
        id: 2,
        states: "TN",
        PAR_30: "4.5%",
        PAR_90: "2.5%",
        PAR_180: "1.7%"
    },
    {
        id: 3,
        states: "KA",
        PAR_30: "4.5%",
        PAR_90: "2.5%",
        PAR_180: "1.7%"
    },
    {
        id: 4,
        states: "UP",
        PAR_30: "4.5%",
        PAR_90: "2.5%",
        PAR_180: "1.7%"
    },
    {
        id: 5,
        states: "MP",
        PAR_30: "4.5%",
        PAR_90: "2.5%",
        PAR_180: "1.7%"
    },
    {
        id: 6,
        states: "OR",
        PAR_30: "4.5%",
        PAR_90: "2.5%",
        PAR_180: "1.7%"
    },
  ];
  