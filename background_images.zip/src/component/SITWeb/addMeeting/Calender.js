// import React, { useState } from "react";
// import Calendar from 'react-calendar'
// import { Button } from "react-bootstrap";
// import 'bootstrap/dist/css/bootstrap.min.css';

// const Calender= () => {
//  return (
// <div style={{marginTop:"600px"}}>
//    Anuj</div>
//  )
// };
// export default Calendar;

import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

const Calendar = () => {
  return (
    <div style={{marginTop:"200px", height:"50px", height:"50px"}}>
      <br></br>
      <input type="date"/>
    </div>
  );
};
export default Calendar;
