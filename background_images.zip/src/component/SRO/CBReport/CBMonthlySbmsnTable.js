import * as React from "react";
import {
  Card,
  Button,
  CardContent,
  CardActionArea,
  Typography,
} from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import "bootstrap/dist/css/bootstrap.min.css";
import Table from "react-bootstrap/Table";
import { useState, useEffect } from "react";
import ReactHTMLTableToExcel from "react-html-table-to-excel-3";
import jsPDF from "jspdf";
import "jspdf-autotable";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import PictureAsPdfIcon from "@mui/icons-material/PictureAsPdf";
import { Dropdown, DropdownMenuItem } from "../../Mudra/dropdown";
import FileDownloadIcon from "@mui/icons-material/FileDownload";

function CBMonthlySbmsnTable(props) {
  const [open, setOpen] = useState(false);
  const [memberData, setMemberData] = useState(null);
  const [industryData, setIndustryData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAllData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Fetch Member Data
        const memberResponse = await fetch('https://api.mfinindia.org/api/auth/table1?month=2025-08&short_name=Annapurna');
        if (!memberResponse.ok) {
          throw new Error('Failed to fetch member data');
        }
        const memberApiData = await memberResponse.json();
        
        // Fetch Industry Data
        const industryResponse = await fetch('https://api.mfinindia.org/api/auth/industryTable2Metrics?month=2025-08&entity=NBFC-MFI');
        if (!industryResponse.ok) {
          throw new Error('Failed to fetch industry data');
        }
        const industryApiData = await industryResponse.json();
        
        console.log('Member API Response:', memberApiData);
        console.log('Industry API Response:', industryApiData);
        
        setMemberData(memberApiData);
        setIndustryData(industryApiData);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError(err.message);
        setLoading(false);
      }
    };

    fetchAllData();
  }, []); 

  const downloadPdfMudraBankWise = (id, filename) => {
    const pdf = new jsPDF();
    pdf.autoTable({ html: "#" + id });
    pdf.save(filename);
  };

  // Function to get member data for a specific month and parameter
  const getMemberMonthData = (month, parameter) => {
    if (!memberData || !memberData.data || !memberData.data[month]) {
      return "N/A";
    }
    
    const monthData = memberData.data[month];
    return monthData[parameter] || "N/A";
  };

  // Function to get industry data for a specific month and parameter
  const getIndustryMonthData = (month, parameter) => {
    if (!industryData || !industryData.data || !industryData.data[month]) {
      return "N/A";
    }
    
    const monthData = industryData.data[month];
    return monthData[parameter] || "N/A";
  };

  if (loading) {
    return (
      <Grid xs={12} sm={12} md={12}>
        <Card style={{ paddingBottom: "20px", marginBottom: "20px" }}>
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Loading data...
            </Typography>
          </CardContent>
        </Card>
      </Grid>
    );
  }

  if (error) {
    return (
      <Grid xs={12} sm={12} md={12}>
        <Card style={{ paddingBottom: "20px", marginBottom: "20px" }}>
          <CardContent>
            <Typography gutterBottom variant="h5" component="div" style={{ color: 'red' }}>
              Error: {error}
            </Typography>
          </CardContent>
        </Card>
      </Grid>
    );
  }

  return (
    <>
      {/* Member Level Table */}
      <Grid xs={12} sm={12} md={12}>
        <Card style={{ paddingBottom: "20px", marginBottom: "20px" }}>
          <CardActionArea>
            <CardContent>
              <Typography
                gutterBottom
                variant="h5"
                style={{
                  textAlign: "left",
                  fontSize: "18px",
                  color: "#bd2f03",
                }}
                component="div"
              >
                Monthly Submission - Member Level{" "}
                <span style={{ float: "right", marginRight: "10px" }}>
                  <Dropdown
                    keepOpen
                    open={open}
                    trigger={
                      <Button
                        style={{ borderBottom: "2px solid", color: "#000000" }}
                        endIcon={<ArrowDropDownIcon />}
                      >
                        Download
                      </Button>
                    }
                    menu={[
                      <DropdownMenuItem>
                        <Button
                          style={{ color: "#000000" }}
                          endIcon={<FileDownloadIcon />}
                        >
                          <ReactHTMLTableToExcel
                            id="test-table-xls-button"
                            className="htmlToExcel"
                            table="table-to-xls-member"
                            filename="custom-report-member-export-excel"
                            filetype="xls"
                            sheet="Mudra Bank Wise Report"
                            buttonText="Excel Format"
                          />
                        </Button>
                      </DropdownMenuItem>,
                      <DropdownMenuItem>
                        <Button
                          onClick={() =>
                            downloadPdfMudraBankWise(
                              "table-to-xls-member",
                              "mudra-bank-wise.pdf"
                            )
                          }
                          style={{ color: "#000000" }}
                          endIcon={<PictureAsPdfIcon />}
                        >
                          PDF Format
                        </Button>
                      </DropdownMenuItem>,
                    ]}
                  />
                </span>
              </Typography>
              <Table
                id="table-to-xls-member"
                striped
                bordered
                hover
                style={{ marginTop: "30px" }}
              >
                <thead>
                  <tr>
                    <th style={{ textAlign: "center" }}>Parameters - Annapurna</th>
                    {memberData && memberData.months && memberData.months.map(month => (
                      <th key={month} style={{ textAlign: "center" }}>{month}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ textAlign: "left" }}>Date of first fortnightly submission</td>
                    {memberData && memberData.months && memberData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getMemberMonthData(month, 'Date_1FortSub')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Date of second fortnightly/monthly submission</td>
                    {memberData && memberData.months && memberData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getMemberMonthData(month, 'Date_2FortSub')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Count of daily submission</td>
                    {memberData && memberData.months && memberData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getMemberMonthData(month, 'DailyFilesSubmitted')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>VID fill rate</td>
                    {memberData && memberData.months && memberData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getMemberMonthData(month, 'VID_fill_rate')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>PAN fill rate</td>
                    {memberData && memberData.months && memberData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getMemberMonthData(month, 'PAN_fill_rate')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Total monthly family income fill rate</td>
                    {memberData && memberData.months && memberData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getMemberMonthData(month, 'Total_monthly_family_income_fill_rate')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Number of instalments fill rate</td>
                    {memberData && memberData.months && memberData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getMemberMonthData(month, 'Number_of_instalments_fill_rate')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Instalment amount fill rate</td>
                    {memberData && memberData.months && memberData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getMemberMonthData(month, 'Instalment_amount_fill_rate')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Valid phone number seeding rate</td>
                    {memberData && memberData.months && memberData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getMemberMonthData(month, 'Valid_phone_number_seeding_rate')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Number of active loan accounts</td>
                    {memberData && memberData.months && memberData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getMemberMonthData(month, 'Number_of_active_loan_accounts')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Value of active loan accounts (in Rs Cr)</td>
                    {memberData && memberData.months && memberData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getMemberMonthData(month, 'Value_of_active_loan_accounts_in_crores')}</td>
                    ))}
                  </tr>
                </tbody>
              </Table>
            </CardContent>
          </CardActionArea>
        </Card>
        <Typography
          gutterBottom
          variant="h5"
          style={{ textAlign: "left", fontSize: "16px", color: "#000" }}
          component="div"
        >
          <strong>Note: </strong>MFIN directs its members to submit/update data
          to the credit bureaus, latest by 07th of the subsequent month with
          submission nobita
        </Typography>
      </Grid>

      {/* Industry Level Table */}
      <Grid xs={12} sm={12} md={12}>
        <Card style={{ paddingBottom: "20px" }}>
          <CardActionArea>
            <CardContent>
              <Typography
                gutterBottom
                variant="h5"
                style={{
                  textAlign: "left",
                  fontSize: "18px",
                  color: "#bd2f03",
                }}
                component="div"
              >
                Monthly Submission - Industry Level
                <span style={{ float: "right", marginRight: "10px" }}>
                  <Dropdown
                    keepOpen
                    open={open}
                    trigger={
                      <Button
                        style={{ borderBottom: "2px solid", color: "#000000" }}
                        endIcon={<ArrowDropDownIcon />}
                      >
                        Download
                      </Button>
                    }
                    menu={[
                      <DropdownMenuItem>
                        <Button
                          style={{ color: "#000000" }}
                          endIcon={<FileDownloadIcon />}
                        >
                          <ReactHTMLTableToExcel
                            id="test-table-xls-button"
                            className="htmlToExcel"
                            table="table-to-xls-industry"
                            filename="custom-report-industry-export-excel"
                            filetype="xls"
                            sheet="Mudra Bank Wise Report"
                            buttonText="Excel Format"
                          />
                        </Button>
                      </DropdownMenuItem>,
                      <DropdownMenuItem>
                        <Button
                          onClick={() =>
                            downloadPdfMudraBankWise(
                              "table-to-xls-industry",
                              "mudra-bank-wise.pdf"
                            )
                          }
                          style={{ color: "#000000" }}
                          endIcon={<PictureAsPdfIcon />}
                        >
                          PDF Format
                        </Button>
                      </DropdownMenuItem>,
                    ]}
                  />
                </span>
              </Typography>
              <Table
                id="table-to-xls-industry"
                striped
                bordered
                hover
                style={{ marginTop: "30px" }}
              >
                <thead>
                  <tr>
                    <th style={{ textAlign: "center" }}>Parameters - Industry</th>
                    {industryData && industryData.months && industryData.months.map(month => (
                      <th key={month} style={{ textAlign: "center" }}>{month}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ textAlign: "left" }}>Lenders submitted first fortnightly file on or before time (i.e. 22nd of the respective month)</td>
                    {industryData && industryData.months && industryData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getIndustryMonthData(month, 'First_Fortnight_File_OnTime')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Lenders submitted second fortnightly/monthly file on or before time (i.e. 7th of the following month)</td>
                    {industryData && industryData.months && industryData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getIndustryMonthData(month, 'Second_Fortnight_File_OnTime')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Lenders submitted min 20 daily files in the month (%)</td>
                    {industryData && industryData.months && industryData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getIndustryMonthData(month, 'Daily_Files_20Plus')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>VID fill rate</td>
                    {industryData && industryData.months && industryData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getIndustryMonthData(month, 'VID_Fill_Rate')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>PAN fill rate</td>
                    {industryData && industryData.months && industryData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getIndustryMonthData(month, 'PAN_Fill_Rate')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Total monthly family income fill rate</td>
                    {industryData && industryData.months && industryData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getIndustryMonthData(month, 'Family_Income_Fill_Rate')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Number of instalments fill rate</td>
                    {industryData && industryData.months && industryData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getIndustryMonthData(month, 'Instalment_Num_Fill_Rate')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Instalment amount fill rate</td>
                    {industryData && industryData.months && industryData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getIndustryMonthData(month, 'Instalment_Amt_Fill_Rate')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Phone number seeding rate</td>
                    {industryData && industryData.months && industryData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getIndustryMonthData(month, 'Phone_Valid_Rate')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Number of active loan accounts</td>
                    {industryData && industryData.months && industryData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getIndustryMonthData(month, 'Active_Loans_Number_inCr')}</td>
                    ))}
                  </tr>
                  <tr>
                    <td style={{ textAlign: "left" }}>Value of active loan accounts (in Rs Cr)</td>
                    {industryData && industryData.months && industryData.months.map(month => (
                      <td key={month} style={{ textAlign: "right" }}>{getIndustryMonthData(month, 'Active_Loans_Value_inCr')}</td>
                    ))}
                  </tr>
                </tbody>
              </Table>
            </CardContent>
          </CardActionArea>
        </Card>
      </Grid>
    </>
  );
}

export default CBMonthlySbmsnTable;