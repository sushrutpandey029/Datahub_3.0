// import React, { useMemo } from "react";
// import ReactApexChart from "react-apexcharts";

// const TicketSizeChartstate = ({
//   data,
//   title = "Ticket Size (%) – State",
//   subtitle = "",
// }) => {
//   // 🔹 Transform API data into ApexChart format
//   const transformTicketAPIData = (apiData) => {
//     if (!apiData || apiData.status !== 200 || !apiData.table) {
//       return { series: [], categories: [], months: [], ticketRanges: [] };
//     }

//     const colors = [
//       "#1e5a8a",
//       "#e87632",
//       "#5a8b3e",
//       "#4fa8d5",
//       "#c74ba0",
//       "#2d5a2d",
//     ];

//     // Extract unique months from column names (e.g., Apr-25_Volume)
//     const months = [];
//     for (let i = 1; i < apiData.columns.length; i += 2) {
//       const month = apiData.columns[i].split("_")[0];
//       months.push(month);
//     }

//     // Ticket ranges with colors
//     const ticketRanges = apiData.table.map((row, idx) => ({
//       key: row["Ticket Size"],
//       color: colors[idx % colors.length],
//     }));

//     // Prepare x-axis categories
//     const categories = [];
//     months.forEach((month) => {
//       categories.push(`${month}_Volume`);
//       categories.push(`${month}_Value`);
//     });

//     // Prepare chart series
//     const series = apiData.table.map((row, rowIndex) => {
//       const name = row["Ticket Size"];
//       const dataPoints = [];

//       months.forEach((month) => {
//         const volKey = `${month}_Volume`;
//         const valKey = `${month}_Value`;
//         const vol = parseFloat((row[volKey] || "0").replace("%", "")) / 100;
//         const val = parseFloat((row[valKey] || "0").replace("%", "")) / 100;
//         dataPoints.push(vol, val);
//       });

//       return {
//         name,
//         data: dataPoints,
//         color: colors[rowIndex % colors.length],
//       };
//     });

//     return { series, categories, months, ticketRanges };
//   };

//   const { series, categories, months, ticketRanges } = useMemo(() => {
//     const transformed = transformTicketAPIData(data);
//     return {
//       series: [...transformed.series].reverse(),
//       categories: transformed.categories,
//       months: transformed.months,
//       ticketRanges: [...transformed.ticketRanges].reverse(),
//     };
//   }, [data]);

//   // Chart options
//   const options = {
//     chart: {
//       type: "bar",
//       stacked: true,
//       toolbar: {
//         show: true,
//         tools: {
//           download: true,
//           selection: true,
//           zoom: true,
//           zoomin: true,
//           zoomout: true,
//           pan: false,
//           reset: true,
//         },
//       },
//     },
//     title: {
//       text: title,
//       align: "left",
//       style: {
//         fontSize: "16px",
//         fontWeight: "bold",
//         fontFamily: "sans-serif",
//       },
//     },
//     plotOptions: {
//       bar: {
//         horizontal: false,
//         borderRadius: 3,
//         columnWidth: "65%",
//       },
//     },
//     dataLabels: {
//       enabled: true,
//       formatter: (val) => (val * 100 >= 1 ? `${Math.round(val * 100)}%` : ""),
//       style: { fontSize: "10px", colors: ["#fff"], fontWeight: 600 },
//     },
//     xaxis: {
//       categories,
//       labels: { show: false }, // hide default labels
//       axisBorder: { show: false },
//       axisTicks: { show: false },
//     },
//     yaxis: {
//       show: false,
//       max: 1,
//     },
//     grid: { show: false },
//     legend: { show: false },
//     colors: ticketRanges.map((item) => item.color),
//   };

//   return (
//     <div>
//       <ReactApexChart
//         options={options}
//         series={series}
//         type="bar"
//         height={380}
//       />

//       {/* Custom X-Axis Labels (Volume / Value + Month) */}
//       <div
//         style={{
//           paddingLeft: "30px",
//           paddingRight: "30px",
//         }}
//       >
//         {/* Volume / Value labels */}
//         <div
//           style={{
//             display: "flex",
//             justifyContent: "space-around",
//             alignItems: "center",
//             gap: "8px",
//           }}
//         >
//           {months.map((month, idx) => (
//             <div
//               key={idx}
//               style={{
//                 display: "flex",
//                 justifyContent: "space-around",
//                 flex: 1,
//                 gap: "6px",
//               }}
//             >
//               <span
//                 style={{
//                   fontSize: "11px",
//                   color: "#666",
//                   fontWeight: 600,
//                   flex: 1,
//                   textAlign: "center",
//                 }}
//               >
//                 Volume
//               </span>
//               <span
//                 style={{
//                   fontSize: "11px",
//                   color: "#666",
//                   fontWeight: 600,
//                   flex: 1,
//                   textAlign: "center",
//                 }}
//               >
//                 Value
//               </span>
//             </div>
//           ))}
//         </div>

//         {/* Month labels */}
//         <div
//           style={{
//             display: "flex",
//             justifyContent: "space-around",
//             marginTop: "8px",
//             alignItems: "center",
//             gap: "8px",
//           }}
//         >
//           {months.map((month, idx) => (
//             <div
//               key={idx}
//               style={{
//                 fontSize: "11px",
//                 color: "#666",
//                 fontWeight: 600,
//                 flex: 1,
//                 textAlign: "center",
//               }}
//             >
//               {month}
//             </div>
//           ))}
//         </div>
//       </div>

//       {/* Ticket Size Color Legend */}
//       <div
//         style={{
//           display: "flex",
//           justifyContent: "center",
//           flexWrap: "wrap",
//           marginTop: "25px",
//           gap: "12px 20px",
//         }}
//       >
//         {[...ticketRanges].reverse().map((item, i) => (
//           <div key={i} style={{ display: "flex", alignItems: "center" }}>
//             <div
//               style={{
//                 width: "12px",
//                 height: "12px",
//                 backgroundColor: item.color,
//                 marginRight: "6px",
//               }}
//             />
//             <span style={{ fontSize: "11px", color: "#444", fontWeight: 500 }}>
//               {item.key}
//             </span>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default TicketSizeChartstate;



//new one
import React, { useMemo, useState, useEffect, useRef } from "react";
import ReactApexChart from "react-apexcharts";

const TicketSizeChartstate = ({
  data,
  title = "Ticket Size (%) – State",
  subtitle = "",
}) => {
  const [hiddenSeries, setHiddenSeries] = useState([]);
  const [hoveredLegend, setHoveredLegend] = useState(null);
  const chartRef = useRef(null);

  // 🔹 Transform API data (Same logic as TicketSizeChart)
  const transformTicketAPIData = (apiData) => {
    if (!apiData || !apiData.table) {
      return { series: [], categories: [], months: [], ticketRanges: [] };
    }

    const colors = ["#1e5a8a", "#e87632", "#5a8b3e", "#4fa8d5", "#c74ba0", "#2d5a2d"];
    const months = [];

    for (let i = 1; i < apiData.columns.length; i += 2) {
      const month = apiData.columns[i].split("_")[0];
      months.push(month);
    }

    const ticketRanges = apiData.table.map((row, idx) => ({
      key: row["Ticket Size"],
      color: colors[idx % colors.length],
      originalIndex: idx
    }));

    const categories = [];
    months.forEach((month) => {
      categories.push(`${month}_Volume`);
      categories.push(`${month}_Value`);
    });

    const series = apiData.table.map((row, rowIndex) => {
      const name = row["Ticket Size"];
      const dataPoints = [];

      for (let i = 1; i < apiData.columns.length; i += 2) {
        const vol = parseFloat((row[apiData.columns[i]] || "0").replace("%", ""));
        const val = parseFloat((row[apiData.columns[i + 1]] || "0").replace("%", ""));
        dataPoints.push(vol, val);
      }

      return {
        name,
        data: dataPoints,
        color: colors[rowIndex % colors.length],
        originalIndex: rowIndex
      };
    });

    return { series, categories, months, ticketRanges };
  };

  // 🔹 Memoized transform + hidden series filter + reverse
  const { series, categories, months, ticketRanges } = useMemo(() => {
    const transformed = transformTicketAPIData(data);

    const filteredSeries = transformed.series
      .filter((s) => !hiddenSeries.includes(s.originalIndex))
      .reverse(); // Same as TicketSizeChart

    return {
      series: filteredSeries,
      categories: transformed.categories,
      months: transformed.months,
      ticketRanges: transformed.ticketRanges
    };
  }, [data, hiddenSeries]);

  const toggleSeries = (originalIndex) => {
    setHiddenSeries((prev) =>
      prev.includes(originalIndex)
        ? prev.filter((i) => i !== originalIndex)
        : [...prev, originalIndex]
    );
  };

  // 🔥 Blur effect (Copied exactly from TicketSizeChart)
  useEffect(() => {
    if (!chartRef.current) return;
    const chartEl = chartRef.current.querySelector(".apexcharts-inner");
    if (!chartEl) return;

    const bars = chartEl.querySelectorAll(".apexcharts-series");

    if (hoveredLegend === null) {
      bars.forEach((bar) => {
        bar.style.opacity = "1";
        bar.style.filter = "none";
      });
      return;
    }

    bars.forEach((bar, idx) => {
      const visibleSeries = series[idx];
      if (!visibleSeries) return;

      if (visibleSeries.originalIndex === hoveredLegend) {
        bar.style.opacity = "1";
        bar.style.filter = "none";
      } else {
        bar.style.opacity = "0.2";
        bar.style.filter = "blur(1px)";
      }
    });
  }, [hoveredLegend, series]);

  const options = {
    chart: {
      type: "bar",
      stacked: true,
      toolbar: {
        show: true,
        tools: {
          download: true,
          selection: false,
          zoom: false,
          zoomin: false,
          zoomout: false,
          pan: false,
          reset: false,
        },
      },
    },
    title: {
      text: title,
      align: "left",
      style: { fontSize: "16px", fontWeight: "bold", fontFamily: "sans-serif" },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 3,
        columnWidth: "65%",
      },
    },
    dataLabels: {
      enabled: true,
      formatter: (val) => (val >= 1 ? `${Math.round(val)}%` : ""),
      style: { fontSize: "10px", colors: ["#fff"], fontWeight: 600 },
    },
    xaxis: {
      categories,
      labels: { show: false },
      axisBorder: { show: false },
      axisTicks: { show: false },
    },
    yaxis: { show: false, max: 100 },
    grid: { show: false },
    legend: { show: false },
  };

  return (
    <div ref={chartRef}>
      <ReactApexChart
        key={hiddenSeries.join("-")}
        options={options}
        series={series}
        type="bar"
        height={380}
      />

      {/* CUSTOM X-AXIS same as TicketSizeChart */}
      <div
        style={{
          marginTop: "-46px",
          paddingLeft: "30px",
          paddingRight: "30px",
          position: "relative",
        }}
      >
        <div
          style={{
            width: "100%",
            height: "2px",
            backgroundColor: "#555",
            position: "absolute",
            top: "0",
            left: "0",
          }}
        />
        <div
          style={{
            display: "flex",
            justifyContent: "space-around",
            alignItems: "center",
            gap: "0px",
            position: "relative",
            paddingTop: "2px",
          }}
        >
          <div
            style={{
              width: "2px",
              height: "18px",
              backgroundColor: "#555",
              position: "absolute",
              left: "0",
              top: "0",
            }}
          />
          {months.map((month, idx) => (
            <div
              key={idx}
              style={{
                display: "flex",
                justifyContent: "space-around",
                flex: 1,
                gap: "6px",
                position: "relative",
              }}
            >
              <span
                style={{
                  fontSize: "11px",
                  color: "#666",
                  fontWeight: 600,
                  flex: 1,
                  textAlign: "center",
                }}
              >
                Volume
              </span>
              <span
                style={{
                  fontSize: "11px",
                  color: "#666",
                  fontWeight: 600,
                  flex: 1,
                  textAlign: "center",
                }}
              >
                Value
              </span>
              <div
                style={{
                  width: "2px",
                  height: "18px",
                  backgroundColor: "#555",
                  position: "absolute",
                  right: "-6px",
                  top: "0",
                }}
              />
            </div>
          ))}
        </div>

        <div
          style={{
            display: "flex",
            justifyContent: "space-around",
            marginTop: "8px",
            alignItems: "center",
            gap: "8px",
          }}
        >
          {months.map((month, idx) => (
            <div
              key={idx}
              style={{
                fontSize: "11px",
                color: "#444",
                fontWeight: 600,
                flex: 1,
                textAlign: "center",
              }}
            >
              {month}
            </div>
          ))}
        </div>
      </div>

      {/* LEGENDS same as TicketSizeChart */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          flexWrap: "wrap",
          marginTop: "25px",
          gap: "12px 20px",
        }}
      >
        {ticketRanges.map((item) => {
          const isHidden = hiddenSeries.includes(item.originalIndex);
          const isHovered = hoveredLegend === item.originalIndex;

          return (
            <div
              key={item.originalIndex}
              style={{
                display: "flex",
                alignItems: "center",
                cursor: "pointer",
                opacity: isHidden ? 0.4 : isHovered ? 1 : hoveredLegend !== null ? 0.3 : 1,
              }}
              onMouseEnter={() => setHoveredLegend(item.originalIndex)}
              onMouseLeave={() => setHoveredLegend(null)}
              onClick={() => toggleSeries(item.originalIndex)}
            >
              <div
                style={{
                  width: "12px",
                  height: "12px",
                  backgroundColor: item.color,
                  marginRight: "6px",
                  border: isHidden ? "2px solid #999" : "none",
                }}
              />
              <span 
                style={{ 
                  fontSize: "11px", 
                  color: "#444", 
                  fontWeight: 500,
                }}
              >
                {item.key}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default TicketSizeChartstate;