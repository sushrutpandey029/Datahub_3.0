// import React, { useMemo } from "react";
// import Chart from "react-apexcharts";

// const TenureSizeChart = ({ data, title = "Tenure Size - All India" }) => {
//   console.log("data in TenureSizeChart",JSON.stringify(data,null,2))
//   const transformTenureAPIData = (apiData) => {
//     if (!apiData) return generateFallbackData();
//     if (apiData.status !== 200) return generateFallbackData();
//     if (!apiData.data || !Array.isArray(apiData.data) || apiData.data.length === 0) return generateFallbackData();

//     const result = [];

//     apiData.data.forEach((monthData) => {
//       if (!monthData.month) return;

//       const month = monthData.month;

//       const volumeData = { name: "Volume", month: month, category: "Volume" };
//       const valueData = { name: "Value", month: month, category: "Value" };

//       const tenureMapping = {
//         "0 to 12": "0 to 12 Months",
//         "13 to 24": "13 to 24 Months",
//         "Gtr 24": "Greater than 24 Months",
//         "0-12": "0 to 12 Months",
//         "13-24": "13 to 24 Months",
//         ">24": "Greater than 24 Months",
//         "0_to_12": "0 to 12 Months",
//         "13_to_24": "13 to 24 Months",
//         "greater_than_24": "Greater than 24 Months"
//       };

//       if (monthData.volume && typeof monthData.volume === 'object') {
//         Object.keys(monthData.volume).forEach(key => {
//           const displayName = tenureMapping[key] || key;
//           const value = monthData.volume[key];
//           volumeData[displayName] = typeof value === 'number' ? value : parseFloat(value) || 0;
//         });
//       } else {
//         volumeData["0 to 12 Months"] = Math.floor(Math.random() * 10) + 5;
//         volumeData["13 to 24 Months"] = Math.floor(Math.random() * 20) + 50;
//         volumeData["Greater than 24 Months"] = 100 - (volumeData["0 to 12 Months"] + volumeData["13 to 24 Months"]);
//       }

//       if (monthData.value && typeof monthData.value === 'object') {
//         Object.keys(monthData.value).forEach(key => {
//           const displayName = tenureMapping[key] || key;
//           const value = monthData.value[key];
//           valueData[displayName] = typeof value === 'number' ? value : parseFloat(value) || 0;
//         });
//       } else {
//         valueData["0 to 12 Months"] = Math.floor(Math.random() * 8) + 4;
//         valueData["13 to 24 Months"] = Math.floor(Math.random() * 15) + 45;
//         valueData["Greater than 24 Months"] = 100 - (valueData["0 to 12 Months"] + valueData["13 to 24 Months"]);
//       }

//       result.push(volumeData);
//       result.push(valueData);
//     });

//     return result.length > 0 ? result : generateFallbackData();
//   };

//   const generateFallbackData = () => {
//     const months = ["Apr-25", "May-25", "Jun-25", "Jul-25", "Aug-25"];
//     const fallbackData = [];

//     months.forEach(month => {
//       const volumeData = {
//         name: "Volume",
//         month: month,
//         category: "Volume",
//         "0 to 12 Months": Math.floor(Math.random() * 10) + 5,
//         "13 to 24 Months": Math.floor(Math.random() * 20) + 50,
//         "Greater than 24 Months": 0
//       };
//       volumeData["Greater than 24 Months"] = 100 - (volumeData["0 to 12 Months"] + volumeData["13 to 24 Months"]);

//       const valueData = {
//         name: "Value",
//         month: month,
//         category: "Value",
//         "0 to 12 Months": Math.floor(Math.random() * 8) + 4,
//         "13 to 24 Months": Math.floor(Math.random() * 15) + 45,
//         "Greater than 24 Months": 0
//       };
//       valueData["Greater than 24 Months"] = 100 - (valueData["0 to 12 Months"] + valueData["13 to 24 Months"]);

//       fallbackData.push(volumeData);
//       fallbackData.push(valueData);
//     });

//     return fallbackData;
//   };

//   const chartData = useMemo(() => transformTenureAPIData(data), [data]);

//   // Create empty categories array to remove Volume/Value labels from x-axis
//   const categories = Array(chartData.length).fill("");

//   // Create annotations for vertical separator lines
//   const annotations = {
//     xaxis: []
//   };

//   // Add vertical lines after every pair of bars (after each Value bar)
//   for (let i = 1; i < chartData.length; i += 2) {
//     if (i < chartData.length) {
//       annotations.xaxis.push({
//         x: i + 0.5,
//         borderColor: "#d0d0d0",
//         borderWidth: 1,
//         opacity: 0.8
//       });
//     }
//   }

//   const series = [
//     {
//       name: "0 to 12 Months",
//       data: chartData.map(item => item["0 to 12 Months"] || 0)
//     },
//     {
//       name: "13 to 24 Months",
//       data: chartData.map(item => item["13 to 24 Months"] || 0)
//     },
//     {
//       name: "Greater than 24 Months",
//       data: chartData.map(item => item["Greater than 24 Months"] || 0)
//     }
//   ];

//   const chartOptions = {
//     chart: {
//       type: "bar",
//       stacked: true,
//       stackType: "100%",
//       toolbar: {
//         show: true,
//         tools: {
//           download: true,
//           selection: false,
//           zoom: false,
//           zoomin: false,
//           zoomout: false,
//           pan: false,
//           reset: false
//         },
//         export: {
//           csv: { filename: "tenure-size-chart" },
//           svg: { filename: "tenure-size-chart" },
//           png: { filename: "tenure-size-chart" }
//         }
//       },
//       animations: { enabled: false }
//     },
//     colors: ["#1f4e78", "#f7941d", "#00a651"],
//     plotOptions: {
//       bar: {
//         horizontal: false,
//         columnWidth: "60%",
//         borderRadius: 0,
//         dataLabels: { position: "center" }
//       }
//     },
//     dataLabels: {
//       enabled: true,
//       formatter: function(val) {
//         return val >= 3 ? `${Math.round(val)}%` : "";
//       },
//       style: {
//         fontSize: "10px",
//         colors: ["#fff"],
//         fontWeight: 500
//       }
//     },
//     xaxis: {
//       categories: categories,
//       axisBorder: { show: false },
//       axisTicks: { show: false },
//       labels: {
//         show: true,
//         style: {
//           colors: "#666",
//           fontSize: "11px"
//         }
//       },
//       annotations: annotations
//     },
//     yaxis: {
//       min: 0,
//       max: 100,
//       labels: { show: false }
//     },
//     tooltip: {
//       enabled: true,
//       theme: "light",
//       style: { fontSize: "11px" },
//       y: {
//         formatter: function(val) {
//           return `${Math.round(val)}%`;
//         }
//       }
//     },
//     legend: {
//       position: "bottom",
//       horizontalAlign: "center",
//       fontSize: "13px",
//       markers: {
//         width: 12,
//         height: 12,
//         radius: 0,
//         strokeWidth: 0
//       },
//       itemMargin: { horizontal: 15, vertical: 5 }
//     },
//     grid: { show: false }
//   };

//   if (!data) {
//     return (
//       <div style={{
//         height: "450px",
//         padding: "16px",
//         display: "flex",
//         alignItems: "center",
//         justifyContent: "center",
//         backgroundColor: "#fff",
//         flexDirection: "column",
//       }}>
//         <p>Loading tenure data...</p>
//       </div>
//     );
//   }

//   // Format the title - replace hyphen with equals sign when showing "Total"
//   const formattedTitle = title.includes("Total")
//     ? title.replace("–", "=")  // Replace hyphen with equals sign for Total
//     : title;

//   return (
//     <div style={{
//       height: "auto",
//       padding: "20px 24px",
//       backgroundColor: "#fff",
//       boxShadow: "none",
//       border: "none"
//     }}>
//       <h2 style={{
//         fontFamily: "Helvetica, Arial, sans-serif",
//         fontWeight: 700,
//         fontSize: "14px",
//         color: "#373d3f",
//         textAlign: "left",
//         marginBottom: "20px",
//         letterSpacing: "0",
//         opacity: 1,
//       }}>
//         {formattedTitle}
//       </h2>

//       <Chart
//         options={chartOptions}
//         series={series}
//         type="bar"
//         height={420}
//       />

//       {/* Perfectly Aligned Labels Section */}
//       <div style={{
//         display: "flex",
//         justifyContent: "space-between",
//         paddingTop: "15px",
//         paddingLeft: "60px",
//         paddingRight: "60px",
//         marginTop: "-10px"
//       }}>
//         {chartData.filter((_, index) => index % 2 === 0).map((item, idx) => (
//           <div key={idx} style={{
//             display: "flex",
//             flexDirection: "column",
//             alignItems: "center",
//             width: "18%",
//             minWidth: "80px"
//           }}>
//             {/* Volume Value Labels - Perfectly Centered */}
//             <div style={{
//               display: "flex",
//               justifyContent: "space-between",
//               width: "100%",
//               marginBottom: "8px"
//             }}>
//               <span style={{
//                 fontSize: "11px",
//                 color: "#666",
//                 fontWeight: "600",
//                 flex: 1,
//                 textAlign: "center"
//               }}>Volume</span>
//               <span style={{
//                 fontSize: "11px",
//                 color: "#666",
//                 fontWeight: "600",
//                 flex: 1,
//                 textAlign: "center"
//               }}>Value</span>
//             </div>

//             {/* Month Label */}
//             <div style={{
//               fontSize: "11px",
//               color: "#666",
//               fontWeight: "600",
//               textAlign: "center",
//               width: "100%"
//             }}>
//               {item.month || ""}
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default TenureSizeChart;

// new one

import React, { useMemo, useState, useEffect, useRef } from "react";
import ReactApexChart from "react-apexcharts";

const TenureSizeChart = ({ data, title = "Tenure Size (%) - All India" }) => {
  const [hiddenSeries, setHiddenSeries] = useState([]);
  const [hoveredLegend, setHoveredLegend] = useState(null);
  const chartRef = useRef(null);

  // 🔹 Transform API data (NO OPTIONAL CHAINING)
  const transformTenureAPIData = (apiData) => {
    if (!apiData || !apiData.data || !Array.isArray(apiData.data)) {
      return { series: [], months: [], categories: [], tenureRanges: [] };
    }

    const colors = ["#1f4e78", "#f7941d", "#00a651"];

    const tenureRanges = [
      { display: "0 to 12 Months", dataKey: "0 to 12", color: colors[0], originalIndex: 0 },
      { display: "13 to 24 Months", dataKey: "13 to 24", color: colors[1], originalIndex: 1 },
      { display: "Greater than 24 Months", dataKey: "Gtr 24", color: colors[2], originalIndex: 2 },
    ];

    const months = apiData.data.map(function (m) {
      return m && m.month ? m.month : "";
    });

    const categories = [];
    for (var i = 0; i < months.length; i++) {
      categories.push(months[i] + "_Volume");
      categories.push(months[i] + "_Value");
    }

    const series = tenureRanges.map(function (range) {
      const dataPoints = [];

      for (var i = 0; i < apiData.data.length; i++) {
        var monthObj = apiData.data[i] || {};
        var vol = monthObj.volume || {};
        var val = monthObj.value || {};

        var volRaw = vol[range.dataKey];
        var valRaw = val[range.dataKey];

        // convert safely
        var volNum = 0;
        if (typeof volRaw === "string") {
          if (volRaw.indexOf("%") !== -1) volNum = parseFloat(volRaw.replace("%", "")) || 0;
          else volNum = Number(volRaw) || 0;
        } else {
          volNum = Number(volRaw) || 0;
        }

        var valNum = 0;
        if (typeof valRaw === "string") {
          if (valRaw.indexOf("%") !== -1) valNum = parseFloat(valRaw.replace("%", "")) || 0;
          else valNum = Number(valRaw) || 0;
        } else {
          valNum = Number(valRaw) || 0;
        }

        dataPoints.push(volNum);
        dataPoints.push(valNum);
      }

      return {
        name: range.display,
        data: dataPoints,
        color: range.color,
        originalIndex: range.originalIndex,
      };
    });

    return { series: series, months: months, categories: categories, tenureRanges: tenureRanges };
  };

  // 🔹 Memo + NO OPTIONAL CHAINING
  const transformed = transformTenureAPIData(data);

  const finalSeries = transformed.series
    .filter(function (s) {
      return hiddenSeries.indexOf(s.originalIndex) === -1;
    })
    .reverse();

  const series = finalSeries;
  const categories = transformed.categories;
  const months = transformed.months;
  const tenureRanges = transformed.tenureRanges;

  const toggleSeries = (originalIndex) => {
    setHiddenSeries(function (prev) {
      if (prev.indexOf(originalIndex) !== -1) {
        return prev.filter(function (i) {
          return i !== originalIndex;
        });
      } else {
        return prev.concat(originalIndex);
      }
    });
  };

  // 🔥 BLUR / OPACITY LOGIC (NO OPTIONAL CHAINING)
  useEffect(() => {
    if (!chartRef.current) return;

    const chartEl = chartRef.current.querySelector(".apexcharts-inner");
    if (!chartEl) return;

    const bars = chartEl.querySelectorAll(".apexcharts-series");

    if (hoveredLegend === null) {
      for (let i = 0; i < bars.length; i++) {
        bars[i].style.opacity = "1";
        bars[i].style.filter = "none";
      }
      return;
    }

    for (let i = 0; i < bars.length; i++) {
      const visibleSeries = series[i];
      if (!visibleSeries) continue;

      if (visibleSeries.originalIndex === hoveredLegend) {
        bars[i].style.opacity = "1";
        bars[i].style.filter = "none";
      } else {
        bars[i].style.opacity = "0.2";
        bars[i].style.filter = "blur(1px)";
      }
    }
  }, [hoveredLegend, series]);

  const options = {
    chart: {
      type: "bar",
      stacked: true,
      toolbar: {
        show: true,
        tools: {
          download: true,
          selection: false,
          zoom: false,
          zoomin: false,
          zoomout: false,
          pan: false,
          reset: false,
        },
      },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 3,
        columnWidth: "65%",
        dataLabels: { position: "center" },
      },
    },
    dataLabels: {
      enabled: true,
      formatter: function (val) {
        return val >= 3 ? Math.round(val) + "%" : "";
      },
      style: { fontSize: "10px", colors: ["#fff"], fontWeight: 600 },
    },
    xaxis: {
      categories: categories,
      labels: { show: false },
      axisBorder: { show: false },
      axisTicks: { show: false },
    },
    yaxis: { show: false, max: 100 },
    grid: { show: false },
    legend: { show: false },
    colors: ["#1f4e78", "#f7941d", "#00a651"],
    tooltip: {
      y: { formatter: function (val) { return Math.round(val) + "%"; } },
    },
    title: {
      text: title,
      align: "left",
      style: {
        fontSize: "16px",
        fontWeight: "bold",
        fontFamily: "sans-serif",
      },
    },
  };

  return (
    <div ref={chartRef}>
      <ReactApexChart
        key={hiddenSeries.join("-")}
        options={options}
        series={series}
        type="bar"
        height={380}
      />

      {/* Custom X axis – Volume/Value + Month + Dividers */}
      <div
        style={{
          marginTop: "-46px",
          paddingLeft: "30px",
          paddingRight: "30px",
          position: "relative",
        }}
      >
        <div
          style={{
            width: "100%",
            height: "2px",
            backgroundColor: "#555",
            position: "absolute",
            top: "0",
            left: "0",
          }}
        />

        <div
          style={{
            display: "flex",
            justifyContent: "space-around",
            alignItems: "center",
            position: "relative",
            paddingTop: "2px",
          }}
        >
          <div
            style={{
              width: "2px",
              height: "18px",
              backgroundColor: "#555",
              position: "absolute",
              left: "0",
              top: "0",
            }}
          />

          {months.map(function (month, idx) {
            return (
              <div
                key={idx}
                style={{
                  display: "flex",
                  justifyContent: "space-around",
                  flex: 1,
                  position: "relative",
                }}
              >
                <span style={{ fontSize: "11px", color: "#666", fontWeight: 600, flex: 1, textAlign: "center" }}>Volume</span>
                <span style={{ fontSize: "11px", color: "#666", fontWeight: 600, flex: 1, textAlign: "center" }}>Value</span>

                <div
                  style={{
                    width: "2px",
                    height: "18px",
                    backgroundColor: "#555",
                    position: "absolute",
                    right: "-6px",
                    top: "0",
                  }}
                />
              </div>
            );
          })}
        </div>

        <div
          style={{
            display: "flex",
            justifyContent: "space-around",
            marginTop: "8px",
            alignItems: "center",
          }}
        >
          {months.map(function (month, idx) {
            return (
              <div
                key={idx}
                style={{
                  fontSize: "11px",
                  color: "#444",
                  fontWeight: 600,
                  flex: 1,
                  textAlign: "center",
                }}
              >
                {month}
              </div>
            );
          })}
        </div>
      </div>

      {/* Custom Interactive Legend */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          flexWrap: "wrap",
          marginTop: "25px",
          gap: "12px 20px",
        }}
      >
        {tenureRanges.map(function (item) {
          const isHidden = hiddenSeries.indexOf(item.originalIndex) !== -1;
          const isHovered = hoveredLegend === item.originalIndex;

          return (
            <div
              key={item.originalIndex}
              style={{
                display: "flex",
                alignItems: "center",
                cursor: "pointer",
                opacity: isHidden ? 0.4 : isHovered ? 1 : hoveredLegend !== null ? 0.3 : 1,
                transition: "opacity 0.25s ease",
              }}
              onMouseEnter={() => setHoveredLegend(item.originalIndex)}
              onMouseLeave={() => setHoveredLegend(null)}
              onClick={() => toggleSeries(item.originalIndex)}
            >
              <div
                style={{
                  width: "12px",
                  height: "12px",
                  backgroundColor: isHidden ? "#ccc" : item.color,
                  marginRight: "6px",
                  border: isHidden ? "2px solid #999" : "none",
                }}
              />
              <span
                style={{
                  fontSize: "11px",
                  color: isHidden ? "#999" : "#444",
                  fontWeight: 500,
                  textDecoration: isHidden ? "line-through" : "none",
                }}
              >
                {item.display}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default TenureSizeChart;
