// import React, { useMemo } from "react";
// import Chart from "react-apexcharts";

// const PaymentSizeChartstate = ({ data, title = "Repayment Frequency (%) – State", subtitle = "" }) => {

//     console.log("data in PaymentSizeChartstate", JSON.stringify(data, null, 2));

//   const transformPaymentAPIData = (apiData) => {
//     if (!apiData) return generateFallbackData();
//     if (apiData.status !== 200) return generateFallbackData();
//     if (!apiData.data || !Array.isArray(apiData.data) || apiData.data.length === 0) return generateFallbackData();

//     const result = [];

//     apiData.data.forEach((monthData) => {
//       if (!monthData.month) return;

//       const month = monthData.month;

//       const volumeData = { name: "Volume", month: month, category: "Volume" };
//       const valueData = { name: "Value", month: month, category: "Value" };

//       const paymentMapping = {
//         "Weekly": "Weekly",
//         "BiWeekly": "BiWeekly",
//         "Monthly": "Monthly",
//         "Quarterly": "Quarterly",
//         "Other": "Other"
//       };

//       if (monthData.volume && typeof monthData.volume === 'object') {
//         Object.keys(monthData.volume).forEach(key => {
//           const displayName = paymentMapping[key] || key;
//           const value = monthData.volume[key];
//           volumeData[displayName] = typeof value === 'number' ? value : parseFloat(value) || 0;
//         });
//       } else {
//         volumeData["Weekly"] = Math.floor(Math.random() * 10) + 25;
//         volumeData["BiWeekly"] = Math.floor(Math.random() * 8) + 12;
//         volumeData["Monthly"] = Math.floor(Math.random() * 15) + 45;
//         volumeData["Quarterly"] = Math.floor(Math.random() * 5) + 2;
//         volumeData["Other"] = 100 - (volumeData["Weekly"] + volumeData["BiWeekly"] + volumeData["Monthly"] + volumeData["Quarterly"]);
//       }

//       if (monthData.value && typeof monthData.value === 'object') {
//         Object.keys(monthData.value).forEach(key => {
//           const displayName = paymentMapping[key] || key;
//           const value = monthData.value[key];
//           valueData[displayName] = typeof value === 'number' ? value : parseFloat(value) || 0;
//         });
//       } else {
//         valueData["Weekly"] = Math.floor(Math.random() * 10) + 23;
//         valueData["BiWeekly"] = Math.floor(Math.random() * 8) + 10;
//         valueData["Monthly"] = Math.floor(Math.random() * 15) + 43;
//         valueData["Quarterly"] = Math.floor(Math.random() * 5) + 2;
//         valueData["Other"] = 100 - (valueData["Weekly"] + valueData["BiWeekly"] + valueData["Monthly"] + valueData["Quarterly"]);
//       }

//       result.push(volumeData);
//       result.push(valueData);
//     });

//     return result.length > 0 ? result : generateFallbackData();
//   };

//   const generateFallbackData = () => {
//     const months = ["Apr-25", "May-25", "Jun-25", "Jul-25", "Aug-25"];
//     const fallbackData = [];

//     months.forEach(month => {
//       const volumeData = {
//         name: "Volume",
//         month: month,
//         category: "Volume",
//         "Weekly": Math.floor(Math.random() * 10) + 25,
//         "BiWeekly": Math.floor(Math.random() * 8) + 12,
//         "Monthly": Math.floor(Math.random() * 15) + 45,
//         "Quarterly": Math.floor(Math.random() * 5) + 2,
//         "Other": 0
//       };
//       volumeData["Other"] = 100 - (volumeData["Weekly"] + volumeData["BiWeekly"] + volumeData["Monthly"] + volumeData["Quarterly"]);

//       const valueData = {
//         name: "Value",
//         month: month,
//         category: "Value",
//         "Weekly": Math.floor(Math.random() * 10) + 23,
//         "BiWeekly": Math.floor(Math.random() * 8) + 10,
//         "Monthly": Math.floor(Math.random() * 15) + 43,
//         "Quarterly": Math.floor(Math.random() * 5) + 2,
//         "Other": 0
//       };
//       valueData["Other"] = 100 - (valueData["Weekly"] + valueData["BiWeekly"] + valueData["Monthly"] + valueData["Quarterly"]);

//       fallbackData.push(volumeData);
//       fallbackData.push(valueData);
//     });

//     return fallbackData;
//   };

//   const chartData = useMemo(() => transformPaymentAPIData(data), [data]);

//   // Create empty categories array to remove Volume/Value labels from x-axis
//   const categories = Array(chartData.length).fill("");

//   // Create annotations for vertical separator lines
//   const annotations = {
//     xaxis: []
//   };

//   // Add vertical lines after every pair of bars (after each Value bar)
//   for (let i = 1; i < chartData.length; i += 2) {
//     if (i < chartData.length) {
//       annotations.xaxis.push({
//         x: i + 0.5,
//         borderColor: "#d0d0d0",
//         borderWidth: 1,
//         opacity: 0.8
//       });
//     }
//   }

//   const series = [
//     {
//       name: "Weekly",
//       data: chartData.map(item => item["Weekly"] || 0)
//     },
//     {
//       name: "BiWeekly",
//       data: chartData.map(item => item["BiWeekly"] || 0)
//     },
//     {
//       name: "Monthly",
//       data: chartData.map(item => item["Monthly"] || 0)
//     },
//     {
//       name: "Quarterly",
//       data: chartData.map(item => item["Quarterly"] || 0)
//     },
//     {
//       name: "Other",
//       data: chartData.map(item => item["Other"] || 0)
//     }
//   ];

//   const chartOptions = {
//     chart: {
//       type: "bar",
//       stacked: true,
//       stackType: "100%",
//       toolbar: {
//         show: true,
//         tools: {
//           download: true,
//           selection: false,
//           zoom: false,
//           zoomin: false,
//           zoomout: false,
//           pan: false,
//           reset: false
//         },
//         export: {
//           csv: { filename: "payment-frequency-chart" },
//           svg: { filename: "payment-frequency-chart" },
//           png: { filename: "payment-frequency-chart" }
//         }
//       },
//       animations: { enabled: false }
//     },
//     colors: ["#1f4e78", "#f7941d", "#00a651", "#4fa8d5", "#c74ba0"],
//     plotOptions: {
//       bar: {
//         horizontal: false,
//         columnWidth: "60%",
//         borderRadius: 0,
//         dataLabels: { position: "center" }
//       }
//     },
//     dataLabels: {
//       enabled: true,
//       formatter: function(val) {
//         return val >= 3 ? `${Math.round(val)}%` : "";
//       },
//       style: {
//         fontSize: "10px",
//         colors: ["#fff"],
//         fontWeight: 500
//       }
//     },
//     xaxis: {
//       categories: categories,
//       axisBorder: { show: false },
//       axisTicks: { show: false },
//       labels: {
//         show: true,
//         style: {
//           colors: "#666",
//           fontSize: "11px"
//         }
//       },
//       annotations: annotations
//     },
//     yaxis: {
//       min: 0,
//       max: 100,
//       labels: { show: false }
//     },
//     tooltip: {
//       enabled: true,
//       theme: "light",
//       style: { fontSize: "11px" },
//       y: {
//         formatter: function(val) {
//           return `${Math.round(val)}%`;
//         }
//       }
//     },
//     legend: {
//       position: "bottom",
//       horizontalAlign: "center",
//       fontSize: "13px",
//       markers: {
//         width: 12,
//         height: 12,
//         radius: 0,
//         strokeWidth: 0
//       },
//       itemMargin: { horizontal: 15, vertical: 5 }
//     },
//     grid: { show: false }
//   };

//   if (!data) {
//     return (
//       <div style={{
//         height: "450px",
//         padding: "16px",
//         display: "flex",
//         alignItems: "center",
//         justifyContent: "center",
//         backgroundColor: "#fff",
//         flexDirection: "column",
//       }}>
//         <p>Loading payment frequency data...</p>
//       </div>
//     );
//   }

//   // Format the title - show both region and state if available in subtitle
//   const formattedTitle = subtitle && subtitle.includes("=")
//     ? `${title} ${subtitle}`  // Show both title and subtitle for region/state
//     : title;

//   return (
//     <div style={{
//       height: "auto",
//       padding: "20px 24px",
//       backgroundColor: "#fff",
//       boxShadow: "none",
//       border: "none"
//     }}>
//       <h2 style={{
//         fontFamily: "Helvetica, Arial, sans-serif",
//         fontWeight: 700,
//         fontSize: "14px",
//         color: "#373d3f",
//         textAlign: "left",
//         marginBottom: "20px",
//         letterSpacing: "0",
//         opacity: 1,
//       }}>
//         {formattedTitle}
//       </h2>

//       <Chart
//         options={chartOptions}
//         series={series}
//         type="bar"
//         height={420}
//       />

//       {/* Perfectly Aligned Labels Section */}
//       <div style={{
//         display: "flex",
//         justifyContent: "space-between",
//         paddingTop: "15px",
//         paddingLeft: "60px",
//         paddingRight: "60px",
//         marginTop: "-10px"
//       }}>
//         {chartData.filter((_, index) => index % 2 === 0).map((item, idx) => (
//           <div key={idx} style={{
//             display: "flex",
//             flexDirection: "column",
//             alignItems: "center",
//             width: "18%",
//             minWidth: "80px"
//           }}>
//             {/* Volume Value Labels - Perfectly Centered */}
//             <div style={{
//               display: "flex",
//               justifyContent: "space-between",
//               width: "100%",
//               marginBottom: "8px"
//             }}>
//               <span style={{
//                 fontSize: "11px",
//                 color: "#666",
//                 fontWeight: "600",
//                 flex: 1,
//                 textAlign: "center"
//               }}>Volume</span>
//               <span style={{
//                 fontSize: "11px",
//                 color: "#666",
//                 fontWeight: "600",
//                 flex: 1,
//                 textAlign: "center"
//               }}>Value</span>
//             </div>

//             {/* Month Label */}
//             <div style={{
//               fontSize: "11px",
//               color: "#666",
//               fontWeight: "600",
//               textAlign: "center",
//               width: "100%"
//             }}>
//               {item.month || ""}
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default PaymentSizeChartstate;

//ne wone


import React, { useMemo, useState, useEffect, useRef } from "react";
import ReactApexChart from "react-apexcharts";

/**
 * PaymentSizeChartstate
 * - same UI and functionality as Ticket/Tenure charts
 * - no optional chaining, only traditional checks
 */
const PaymentSizeChartstate = ({
  data,
  title = "Repayment Frequency (%) – State",
  subtitle = "",
}) => {
  // Shared colors at component scope (avoid no-undef lint)
  const COLORS = ["#1f4e78", "#f7941d", "#00a651", "#4fa8d5", "#c74ba0"];

  const [hiddenSeries, setHiddenSeries] = useState([]);
  const [hoveredLegend, setHoveredLegend] = useState(null);
  const chartRef = useRef(null);

  // -------------------------
  // Transform API data (no optional chaining)
  // -------------------------
  const transformPaymentAPIData = (apiData) => {
    if (!apiData || apiData.status !== 200 || !apiData.data || !Array.isArray(apiData.data)) {
      return { series: [], months: [], categories: [], paymentRanges: [] };
    }

    var colors = COLORS.slice(); // keep local copy if needed

    var paymentRanges = [
      { display: "Weekly", dataKey: "Weekly", color: colors[0], originalIndex: 0 },
      { display: "BiWeekly", dataKey: "BiWeekly", color: colors[1], originalIndex: 1 },
      { display: "Monthly", dataKey: "Monthly", color: colors[2], originalIndex: 2 },
      { display: "Quarterly", dataKey: "Quarterly", color: colors[3], originalIndex: 3 },
      { display: "Other", dataKey: "Other", color: colors[4], originalIndex: 4 },
    ];

    // Build months array
    var months = apiData.data.map(function (m) {
      return m && m.month ? m.month : "";
    });

    // Build categories [Mon_Volume, Mon_Value, ...]
    var categories = [];
    for (var i = 0; i < months.length; i++) {
      categories.push(months[i] + "_Volume");
      categories.push(months[i] + "_Value");
    }

    // Build series in original order (so originalIndex matches)
    var series = paymentRanges.map(function (range) {
      var dataPoints = [];

      for (var j = 0; j < apiData.data.length; j++) {
        var monthObj = apiData.data[j] || {};
        var vol = monthObj.volume ? monthObj.volume : {};
        var val = monthObj.value ? monthObj.value : {};

        var volRaw = vol[range.dataKey];
        var valRaw = val[range.dataKey];

        // convert safely (support numbers and numeric strings)
        var volNum = 0;
        if (typeof volRaw === "string") {
          if (volRaw.indexOf("%") !== -1) volNum = parseFloat(volRaw.replace("%", "")) || 0;
          else volNum = Number(volRaw) || 0;
        } else {
          volNum = Number(volRaw) || 0;
        }

        var valNum = 0;
        if (typeof valRaw === "string") {
          if (valRaw.indexOf("%") !== -1) valNum = parseFloat(valRaw.replace("%", "")) || 0;
          else valNum = Number(valRaw) || 0;
        } else {
          valNum = Number(valRaw) || 0;
        }

        dataPoints.push(volNum);
        dataPoints.push(valNum);
      }

      return {
        name: range.display,
        data: dataPoints,
        color: range.color,
        originalIndex: range.originalIndex,
      };
    });

    return { series: series, months: months, categories: categories, paymentRanges: paymentRanges };
  };

  // -------------------------
  // Memoized transform + filter + reverse
  // -------------------------
  const transformed = useMemo(function () {
    return transformPaymentAPIData(data);
  }, [data]);

  var finalSeries = [];
  if (transformed.series && Array.isArray(transformed.series)) {
    finalSeries = transformed.series
      .filter(function (s) {
        return hiddenSeries.indexOf(s.originalIndex) === -1;
      })
      .reverse(); // reverse for stacked display order (DOM matches series[])
  }

  var series = finalSeries;
  var categories = transformed.categories;
  var months = transformed.months;
  var paymentRanges = transformed.paymentRanges;

  // -------------------------
  // Toggle series visibility (legend click)
  // -------------------------
  var toggleSeries = function (originalIndex) {
    setHiddenSeries(function (prev) {
      if (prev.indexOf(originalIndex) !== -1) {
        return prev.filter(function (i) {
          return i !== originalIndex;
        });
      } else {
        return prev.concat(originalIndex);
      }
    });
  };

  // -------------------------
  // Hover legend effect: blur other bars (DOM based)
  // -------------------------
  useEffect(function () {
    if (!chartRef.current) return;

    var chartEl = chartRef.current.querySelector(".apexcharts-inner");
    if (!chartEl) return;

    var bars = chartEl.querySelectorAll(".apexcharts-series");

    if (hoveredLegend === null) {
      for (var i = 0; i < bars.length; i++) {
        bars[i].style.opacity = "1";
        bars[i].style.filter = "none";
      }
      return;
    }

    for (var k = 0; k < bars.length; k++) {
      var visibleSeries = series[k];
      if (!visibleSeries) continue;

      if (visibleSeries.originalIndex === hoveredLegend) {
        bars[k].style.opacity = "1";
        bars[k].style.filter = "none";
      } else {
        bars[k].style.opacity = "0.2";
        bars[k].style.filter = "blur(1px)";
      }
    }
  }, [hoveredLegend, series]);

  // -------------------------
  // Apex options
  // -------------------------
  var options = {
    chart: {
      type: "bar",
      stacked: true,
      toolbar: {
        show: true,
        tools: {
          download: true,
          selection: false,
          zoom: false,
          zoomin: false,
          zoomout: false,
          pan: false,
          reset: false,
        },
      },
    },
    title: {
      text: subtitle && subtitle.length > 0 ? title + " (" + subtitle + ")" : title,
      align: "left",
      style: {
        fontSize: "16px",
        fontWeight: "bold",
        fontFamily: "sans-serif",
      },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 3,
        columnWidth: "65%",
      },
    },
    dataLabels: {
      enabled: true,
      formatter: function (val) {
        return val >= 3 ? Math.round(val) + "%" : "";
      },
      style: { fontSize: "10px", colors: ["#fff"], fontWeight: 600 },
    },
    xaxis: {
      categories: categories,
      labels: { show: false },
      axisBorder: { show: false },
      axisTicks: { show: false },
    },
    yaxis: { show: false, max: 100 },
    grid: { show: false },
    legend: { show: false },
    colors: COLORS,
    tooltip: {
      y: { formatter: function (val) { return Math.round(val) + "%"; } },
    },
  };

  // -------------------------
  // Loading fallback
  // -------------------------
  if (!data || !data.data) {
    return (
      <div
        style={{
          height: "450px",
          padding: "16px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#fff",
          flexDirection: "column",
        }}
      >
        <p>Loading payment frequency data...</p>
      </div>
    );
  }

  // -------------------------
  // Render
  // -------------------------
  return (
    <div ref={chartRef}>
      <ReactApexChart key={hiddenSeries.join("-")} options={options} series={series} type="bar" height={380} />

      {/* Custom X axis – bold horizontal + Volume/Value + month + vertical dividers */}
      <div
        style={{
          marginTop: "-46px",
          paddingLeft: "30px",
          paddingRight: "30px",
          position: "relative",
        }}
      >
        {/* Bold horizontal line */}
        <div
          style={{
            width: "100%",
            height: "2px",
            backgroundColor: "#555",
            position: "absolute",
            top: "0",
            left: "0",
          }}
        />

        <div
          style={{
            display: "flex",
            justifyContent: "space-around",
            alignItems: "center",
            position: "relative",
            paddingTop: "2px",
          }}
        >
          <div
            style={{
              width: "2px",
              height: "18px",
              backgroundColor: "#555",
              position: "absolute",
              left: "0",
              top: "0",
            }}
          />

          {months.map(function (month, idx) {
            return (
              <div
                key={idx}
                style={{
                  display: "flex",
                  justifyContent: "space-around",
                  flex: 1,
                  position: "relative",
                }}
              >
                <span style={{ fontSize: "11px", color: "#666", fontWeight: 600, flex: 1, textAlign: "center" }}>Volume</span>
                <span style={{ fontSize: "11px", color: "#666", fontWeight: 600, flex: 1, textAlign: "center" }}>Value</span>

                <div
                  style={{
                    width: "2px",
                    height: "18px",
                    backgroundColor: "#555",
                    position: "absolute",
                    right: "-6px",
                    top: "0",
                  }}
                />
              </div>
            );
          })}
        </div>

        <div
          style={{
            display: "flex",
            justifyContent: "space-around",
            marginTop: "8px",
            alignItems: "center",
          }}
        >
          {months.map(function (month, idx) {
            return (
              <div
                key={idx}
                style={{
                  fontSize: "11px",
                  color: "#444",
                  fontWeight: 600,
                  flex: 1,
                  textAlign: "center",
                }}
              >
                {month}
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive Legend */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          flexWrap: "wrap",
          marginTop: "25px",
          gap: "12px 20px",
        }}
      >
        {paymentRanges &&
          paymentRanges.map(function (item) {
            var isHidden = hiddenSeries.indexOf(item.originalIndex) !== -1;
            var isHovered = hoveredLegend === item.originalIndex;

            return (
              <div
                key={item.originalIndex}
                style={{
                  display: "flex",
                  alignItems: "center",
                  cursor: "pointer",
                  opacity: isHidden ? 0.4 : isHovered ? 1 : hoveredLegend !== null ? 0.3 : 1,
                  transition: "opacity 0.25s ease",
                }}
                onMouseEnter={function () {
                  setHoveredLegend(item.originalIndex);
                }}
                onMouseLeave={function () {
                  setHoveredLegend(null);
                }}
                onClick={function () {
                  toggleSeries(item.originalIndex);
                }}
              >
                <div
                  style={{
                    width: "12px",
                    height: "12px",
                    backgroundColor: isHidden ? "#ccc" : item.color,
                    marginRight: "6px",
                    border: isHidden ? "2px solid #999" : "none",
                  }}
                />
                <span
                  style={{
                    fontSize: "11px",
                    color: isHidden ? "#999" : "#444",
                    fontWeight: 500,
                    textDecoration: isHidden ? "line-through" : "none",
                  }}
                >
                  {item.display}
                </span>
              </div>
            );
          })}
      </div>
    </div>
  );
};

export default PaymentSizeChartstate;
