export default [
  {
    id: 1,
    serial_number: 1,
    type_of_entity: "Universe",
    no_active_entities: "100"
  },
  {
    id: 2,
    serial_number: 2,
    type_of_entity: "NBFC-MFI",
    no_active_entities: "200"
  },
  {
    id: 3,
    serial_number: 3,
    type_of_entity: "Banks",
    no_active_entities: "1000"
  },
  {
    id: 4,
    serial_number: 4,
    type_of_entity: "SFB",
    no_active_entities: "1000"
  },
  {
    id: 5,
    serial_number: 5,
    type_of_entity: "NBFC",
    no_active_entities: "35"
  },
  {
    id: 6,
    serial_number: 5,
    type_of_entity: "Other",
    no_active_entities: "35"
  },
];