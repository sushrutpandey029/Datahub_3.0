export default [
    {
      id: 1,
      sr_no: 1,
      period: "2021-2022",
      state: "Andhra Pradesh/Anantapur",
      shishu_no_of_acs: "56804",
      kishore_no_of_acs:'28120',
      tarun_no_of_acs:"3237",
      total_no_of_acs:"88161",
      created_at:"2023-01-31 02:10:38",
      updated_at:"2023-01-31 02:10:38"
    },
    {
      id: 2,
      sr_no: 2,
      period: "2021-2022",
      state: "Uttar Prakash/Noida",
      shishu_no_of_acs: "56804",
      kishore_no_of_acs:'28120',
      tarun_no_of_acs:"3237",
      total_no_of_acs:"88161",
      created_at:"2023-01-31 02:10:38",
      updated_at:"2023-01-31 02:10:38"
    }
  ];
  